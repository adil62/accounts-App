<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Print records</title>
    <link rel="stylesheet" href="vendor/css/bootstrap-4.1.2-dist/bootstrap.css">
    <link rel="stylesheet" href="resources/css/deposit_bank.php">
</head>
<body>
    <div class="container">
        <form action="" method="post" form-group>
            <input type="text" name="input" form-control>
        </form>
        
    </div>
</body>
</html>